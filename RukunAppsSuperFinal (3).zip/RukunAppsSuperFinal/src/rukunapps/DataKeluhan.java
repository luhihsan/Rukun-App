package rukunapps;

public class DataKeluhan {

    public DataKeluhan(String laporan) {
        this.laporan = laporan;
    }

    private String laporan;

    public String getLaporan() {
        return laporan;
    }

    public void setLaporan(String laporan) {
        this.laporan = laporan;
    }

}
